#include <msp430.h> 

/*
 * main.c
 */
int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	
    int i;

    P1OUT |= BIT5;
    P1DIR |= BIT5;
    P1SEL = BIT1 | BIT2 | BIT4;
    P1SEL2 = BIT1 | BIT2 | BIT4;

    UCA0CTL1 = UCSWRST;
       UCA0CTL0 |= UCCKPH + UCMSB + UCMST + UCSYNC;  // 3-pin, 8-bit SPI master
       UCA0CTL1 |= UCSSEL_2;                     // SMCLK
       UCA0BR0 |= 0x02;                          // /2
       UCA0BR1 = 0;                              //
       UCA0MCTL = 0;                             // No modulation
       UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**

       P1OUT &= (~BIT5); // Select Device

       for(i=0; i<12*24/8; i++)
       {
           while (!(IFG2 & UCA0TXIFG));   // USCI_A0 TX buffer ready?
           UCA0TXBUF = 0xAA;              // Send 0xAA over SPI to Slave
       }
       P1OUT |= (BIT5);               // Unselect Device

	return 0;
}
